# microservice_spring_cloud
Projeto do curso do Udemy (Arquitetura Microserviços com Spring Cloud Netflix)
